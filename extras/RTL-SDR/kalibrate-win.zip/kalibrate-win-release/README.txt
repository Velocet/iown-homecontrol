This is just a quick windows build of https://github.com/steve-m/kalibrate-rtl

Used libraries:
http://sourceforge.net/projects/libusb/files/libusb-1.0/libusb-1.0.9/libusb-1.0.9.tar.bz2
ftp://ftp.fftw.org/pub/fftw/old/fftw-3.3.1.pl1-dll32.zip
http://sources.redhat.com/pthreads-win32/ cvs
and, of course, http://cgit.osmocom.org/cgit/rtl-sdr/

See the corresponding COPYING* files for the license text.