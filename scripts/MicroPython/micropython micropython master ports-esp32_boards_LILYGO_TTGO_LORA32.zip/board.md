The following files are daily firmware for the LILYGO TTGO LoRa32.

Support for hardware versions v1.0, v1.2, v1.6 and v2.0.
